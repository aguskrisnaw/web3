const pages = [
  {
    title: 'Home',
    href: '/',
  },
  {
    title: 'Create NFT',
    href: '/create',
  },
  {
    title: 'All NFTs',
    href: '/allNfts',
  },
];

export default pages;
