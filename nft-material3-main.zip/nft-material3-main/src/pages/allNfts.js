import React from 'react';
import AllNfts from 'views/AllNfts';

const AllNftsPage = () => {
  return <AllNfts />;
};

export default AllNftsPage;
