import React from 'react';
import Assets from 'views/Assets';

const AssetsPage = () => {
  return <Assets />;
};

export default AssetsPage;
