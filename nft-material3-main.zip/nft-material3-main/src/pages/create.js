import React from 'react';
import Create from 'views/Create';

const CreatePage = () => {
  return <Create />;
};

export default CreatePage;
