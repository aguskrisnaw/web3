import React from 'react';
import NotFound from 'views/NotFound';

const NotFoundPage = () => {
  return <NotFound />;
};

export default NotFoundPage;
